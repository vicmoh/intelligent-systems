import java.util.ArrayList;

/**
 * DTLearn class is used to perform the decision learning tree algorithm 
 * @author Le
 */
public class DTLeaner {
    Scheme aScheme;
    DataSet dataSet;
    
    
    /* decisionTreeLearning method implements decision tree learning algorithm */
    public Node decisionTreeLearning(){
        
        return new Node();
    }
    
    /*
    the method majorityValue calculate the majority of target value of data set.
    */
    public String majorityValue(ArrayList<Example> dataset){
        return "";
    }
    /*
    The method sameClassification check if the dataset has the same classification.
    It returns the value of the same class
    */
    public String sameClassification(ArrayList<Example> dataset){
        return "";
    }
    

    
}

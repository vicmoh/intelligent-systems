

/**
 * A utility class to store some static commonly used methods
 * @author Le
 */
public class Util {
    
    
}

/**
 *
 * @author Le
 */
public class Node {
    String nodeLabel = ""; //attribute Name
    String linkLabel = ""; //atribute values of parent
    Node parent = null;    

    public Node() {
    }
    
}

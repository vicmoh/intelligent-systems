/**
 * This class is a proposition symbol
 * @author Le
 */
public class Symbol {
    private String symbol;  //a proposition symbol  
}

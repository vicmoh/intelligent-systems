import java.util.ArrayList;

class Example {
    // Attributes
    public ArrayList<Integer> attribIndices;
    public int funcIndex;

    // Constructors
    public Example(ArrayList<Integer> attribIndices, int funcIndex) {
        this.attribIndices = attribIndices;
        this.funcIndex = funcIndex;
    }
}

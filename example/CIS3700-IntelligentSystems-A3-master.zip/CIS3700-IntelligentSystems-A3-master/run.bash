java DTLearn loan-sche.txt loan-samp.txt;

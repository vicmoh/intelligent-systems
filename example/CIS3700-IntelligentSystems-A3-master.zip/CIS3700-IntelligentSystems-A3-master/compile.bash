javac DTLearn.java;

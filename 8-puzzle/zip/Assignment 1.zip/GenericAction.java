
/**
 *
 * @author Le
 */
public interface GenericAction {
     void printAction(); //print out the action instance.
}
